const startBtn = document.getElementById('start');
const stopBtn = document.getElementById('stop');
const preview = document.getElementById('preview');
const qualityInput = document.getElementById('quality');

let mediaRecorder;
let recordedChunks = [];

startBtn.addEventListener('click', startRecording);
stopBtn.addEventListener('click', stopRecording);
qualityInput.addEventListener('input', setQuality);

async function startRecording() {
  try {
    const stream = await navigator.mediaDevices.getDisplayMedia({ video: { width: 1920, height: 1080, frameRate: 30 } });
    mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm; codecs=vp9' });
    mediaRecorder.addEventListener('dataavailable', handleDataAvailable);
    mediaRecorder.start();
    startBtn.style.display = 'none';
    stopBtn.style.display = 'inline-block';
    preview.srcObject = stream;
    preview.muted = true;
    preview.play();
  } catch (err) {
    console.error('Error: ' + err);
  }
}

function stopRecording() {
  mediaRecorder.stop();
  startBtn.style.display = 'inline-block';
  stopBtn.style.display = 'none';
  preview.srcObject = null;
}

function handleDataAvailable(e) {
  recordedChunks.push(e.data);
  download();
}

function download() {
  const blob = new Blob(recordedChunks, {
    type: 'video/webm'
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'screen-recording.webm';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    recordedChunks = [];
  }, 100);
}

function setQuality() {
  const quality = qualityInput.value;
  const bitrate = getBitrate(quality);
  const stream = preview.srcObject;
  const tracks = stream.getTracks();
  tracks.forEach(track => {
    const settings = track.getSettings();
    settings.video.bitrate = bitrate;
    track.applyConstraints(settings);
  });
}

function getBitrate(quality) {
  switch (quality) {
    case '0':
      return 250000; // Low
    case '1':
      return 500000; // Medium
    case '2':
      return 1000000; // High (default)
    case '3':
      return 2000000; // Ultra
    default:
      return 1000000;
  }
}

